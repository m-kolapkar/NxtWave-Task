package com.example.demo.Service;

import java.util.List;

import com.example.demo.Entity.User;

public interface UserService 
{
       public void register(User u1);
       
       public List<User> getAllInfo();
       
       public void deletesomerecord(int id);
       
       public User getSingleInfo(int id);
}
