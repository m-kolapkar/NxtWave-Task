package com.example.demo.Dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.User;
import com.example.demo.Repo.UserRepo;
import com.example.demo.Service.UserService;


@Service
public class UserDao implements UserService
{
	@Autowired
   UserRepo up;
	
	@Override
	public void register(User u1) {
		
		up.save(u1);
	}

	@Override
	public List<User> getAllInfo() {
		
		return up.findAll();
	}

	@Override
	public void deletesomerecord(int id) 
	{
		
		up.deleteById(id);
	}

	@Override
	public User getSingleInfo(int id) {
		
		return up.getById(id);
	}

}
