package com.example.demo.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class User 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	   private int uid;
       public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	private String uname;
       private int Mo_No;
       private String Pan_No;
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public int getMo_No() {
		return Mo_No;
	}
	public void setMo_No(int mo_No) {
		Mo_No = mo_No;
	}
	public String getPan_No() {
		return Pan_No;
	}
	public void setPan_No(String pan_No) {
		Pan_No = pan_No;
	}
       
       
       
}
