package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;


import com.example.demo.Entity.User;
import com.example.demo.Service.UserService;


@Controller
public class HomeController {

	@Autowired
	UserService us;
	
    @RequestMapping("/")
	public String one()
	{
		return "index";
	}
    @PostMapping("/next")
    public String getdata(@ModelAttribute("ur") User ur) 
    {	
    	return "index";
    }
    @RequestMapping("/disp")
    public String two(Model m)
    {
    	List<User> ck = us.getAllInfo();
    	m.addAttribute("mm",ck);
    	return "disp";
    }
    
    @GetMapping("del/{id}")
    public String three(@PathVariable int id)
    {
    	us.deletesomerecord(id);
    	return "redirect:/disp";
    }
    @GetMapping("/edit/{id}")
    public String four(@PathVariable int id,Model m)
    {
    	User ct=us.getSingleInfo(id);
    	m.addAttribute("kk",ct);
    	return "edit";
    }
    @PostMapping("/update")
    public String up_data(@ModelAttribute("cf") User cf)
    {
    	User u = new User ();
    	u.setUid(cf.getUid());
    	u.setUname(cf.getUname());
    	u.setMo_No(cf.getMo_No());
    	u.setPan_No(cf.getPan_No());
    	
        us.register(u);
    	
    	return "redirect:/disp";
    }
}
